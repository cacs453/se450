package example.domain;

import example.common.CannotFitException;
import example.common.InvalidDataException;
import example.common.Point3D;
import example.common.TruckImplFactory;
import example.truck.Truck;

/**
 * The implementation class for the StandardCargoTruck, which implements Truck interface.
 */
public class ContainerTruck implements Truck {

    private Truck myTruck; // Delegate - will refer to some implementation object

     /**
     * The constructor function.
     * @param lX - x coordinate of the location.
     * @param lY - y coordinate of the location.
     * @param lZ - z coordinate of the location.
     * @param dX - x coordinate of the destination.
     * @param dY - y coordinate of the destination.
     * @param dZ - z coordinate of the destination.
     * @param spd - The current speed.
     * @param mxSpd - The maximum speed.
     * @param mlw   - The maximum load weight.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    public ContainerTruck(double lX, double lY, double lZ, double dX, double dY, double dZ,
            double spd, double mxSpd, double mlw) throws InvalidDataException {
        myTruck = TruckImplFactory.createTruck(lX, lY, lZ, dX, dY, dZ, spd, mxSpd, mlw);
    }

    /**
     * The constructor function.
     * @param loc - The Point3D value of the location.
     * @param dest - The Point3D value of the destination.
     * @param spd - The current speed.
     * @param mxSpd - The maximum speed.
     * @param mlw   - The maximum load weight.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */       
    public ContainerTruck(Point3D loc, Point3D dest, double spd, double mxSpd, double mlw) throws InvalidDataException {
        this(loc.getX(), loc.getY(), loc.getZ(), dest.getX(), dest.getY(), dest.getZ(), spd, mxSpd, mlw);
    }

    /**
     * Check if the load value equals the max load weight, if not, throws InvalidDataException
     * @param amount - The load weight.
     * @throws InvalidDataException 
     */
    private void verifyLoadValue(double amount) throws InvalidDataException {
        if (amount != getMaxLoadWeight()) {
            throw new InvalidDataException("A Container Truck can only be *fully* loaded (" + getMaxLoadWeight()
                    + ")- not partially loaded (" + amount + ")");
        }
    }

    /**
     * Load the specific weight.
     * @param amount - The specific load weight.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     * @throws CannotFitException   - The exception which means the specific load weight cannot fit into the truck.
     */    
    @Override
    public void load(double amount) throws InvalidDataException, CannotFitException {
        verifyLoadValue(amount);
        setCurrentLoadWeight(amount);
    }

    /**
     * Unload the specific weight.
     * @param amount - The specific unload weight.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     * @throws CannotFitException   - The exception which means the specific unload weight cannot be fulfilled.
     */       
    @Override
    public void unLoad(double amount) throws InvalidDataException, CannotFitException {
        if (amount != getCurrentLoadWeight()) {
            throw new InvalidDataException("A Container Truck can only be *fully* unloaded (" + getMaxLoadWeight()
                    + ")- not partially unloaded (" + amount + ")");
        }
        setCurrentLoadWeight(0.0);
    }

     /**
     * Check if the instance is at the destination.
     * @return If the instance is at the destination.
     */    
    @Override
    public boolean atDestination() {
        return myTruck.atDestination();
    }

    /**
     * Get the Point3D value of the destination.
     * @return The Point3D value of the destination.
     */     
    @Override
    public Point3D getDestination() {
        return myTruck.getDestination();
    }

     /**
     * Get x coordinate of the destination.
     * @return x coordinate of the destination.
     */      
    @Override
    public double getDestinationX() {
        return myTruck.getDestinationX();
    }

     /**
     * Get y coordinate of the destination.
     * @return y coordinate of the destination.
     */      
    @Override
    public double getDestinationY() {
        return myTruck.getDestinationY();
    }

     /**
     * Get z coordinate of the destination.
     * @return z coordinate of the destination.
     */      
    @Override
    public double getDestinationZ() {
        return myTruck.getDestinationZ();
    }

     /**
     * Get the maximum speed.
     * @return The maximum speed.
     */
    @Override
    public double getMaxSpeed() {
        return myTruck.getMaxSpeed();
    }

    /**
     * Get the current speed.
     * @return The current speed.
     */    
    @Override
    public double getSpeed() {
        return myTruck.getSpeed();
    }

    /**
     * Set the destination with the specific x, y, z coordinates.
     * @param x - x coordinate of the destination.
     * @param y - y coordinate of the destination.
     * @param z - z coordinate of the destination.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */    
    @Override
    public void setDestination(double x, double y, double z) throws InvalidDataException {
        myTruck.setDestination(x, y, z);
    }

    /**
     * Set the destination with the specific Point3D value.
     * @param aPoint - The specific Point3D value.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */      
    @Override
    public void setDestination(Point3D aPoint) throws InvalidDataException {
        myTruck.setDestination(aPoint);
    }

     /**
     * Set the maximum speed.
     * @param ms - The specific maximum speed.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */ 
    @Override
    public void setMaxSpeed(double ms) throws InvalidDataException {
        myTruck.setMaxSpeed(ms);
    }

    /**
     * Set the current speed.
     * @param s - The specific current speed.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */    
    @Override
    public void setSpeed(double s) throws InvalidDataException {
        myTruck.setSpeed(s);
    }

    /**
     * Calculate the distance from the specific location.
     * @param loc - The specific location.
     * @return The distance from the specific location.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     * @see example.location.LocatableImpl#distance(example.common.Point3D) 
     */     
    @Override
    public double distance(Point3D loc) throws InvalidDataException {
        return myTruck.distance(loc);
    }

     /**
     * Calculate the distance from the other specific location.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @return The distance from the other specific location
     * @throws InvalidDataException - Invalid inputted parameter exception.
     * @see example.location.LocatableImpl#distance(double, double, double)
     */     
    @Override
    public double distance(double x, double y, double z) throws InvalidDataException {
        return myTruck.distance(x, y, z);
    }

   /**
     * Get the Point3D value of the location.
     * @return - The Point3D value of the location.
     */     
    @Override
    public Point3D getLocation() {
        return myTruck.getLocation();
    }

    /**
     * Get the x coordinate of the location.
     * @return - The x coordinate of the location.
     */      
    @Override
    public double getLocationX() {
        return myTruck.getLocationX();
    }

    /**
     * Get the y coordinate of the location.
     * @return - The y coordinate of the location.
     */      
    @Override
    public double getLocationY() {
        return myTruck.getLocationY();
    }

    /**
     * Get the z coordinate of the location.
     * @return - The z coordinate of the location.
     */      
    @Override
    public double getLocationZ() {
        return myTruck.getLocationZ();
    }

    /**
     * Set the location with the specific Point3D value.
     * @param loc - The specific Point3D value.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */     
    @Override
    public void setLocation(Point3D loc) throws InvalidDataException {
        myTruck.setLocation(loc);
    }

    /**
     * Set the location with 3 coordinates.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */        
    @Override
    public void setLocation(double x, double y, double z) throws InvalidDataException {
        myTruck.setLocation(x, y, z);
    }

    /**
     * Get the identifier.
     * @return The identifier.
     */    
    @Override
    public String getIdentifier() {
        return myTruck.getIdentifier();
    }

    /**
     * Get the maximum load weight.
     * @return The maximum load weight
     */  
    @Override
    public double getMaxLoadWeight() {
        return myTruck.getMaxLoadWeight();
    }

     /**
     * Set the current load weight.
     * @param d - The specific current load weight.
     */ 
    @Override
    public void setCurrentLoadWeight(double d) {
        myTruck.setCurrentLoadWeight(d);
    }

    /**
     * Get the current load weight.
     * @return The current load weight.
     */    
    @Override
    public double getCurrentLoadWeight() {
        return myTruck.getCurrentLoadWeight();
    }

    /**
     * Update the location with the specific time interval.
     * @param millis - The specific time interval
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */         
    @Override
    public void update(double millis) throws InvalidDataException {
        myTruck.update(millis);
    }

    /**
     * Output string of the information of the instance.
     * @return String of the information of the instance
     */    
    @Override
    public String toString() {
        try {
            return "I am ContainerTruck " + getIdentifier() + ".\n\tI am at "
                    + getLocation() + " and am heading to " + getDestination()
                    + ".\n\tMy load is " + getCurrentLoadWeight() + " and my max load is "
                    + getMaxLoadWeight() + ".\n\tDistance to my destination is "
                    + String.format("%4.2f", distance(getDestination())) + ". "
                    + (atDestination() ? "I am there!" : "I'm not there yet");
        } catch (InvalidDataException ex) {
            return ex.getMessage();
        }
    }

}
