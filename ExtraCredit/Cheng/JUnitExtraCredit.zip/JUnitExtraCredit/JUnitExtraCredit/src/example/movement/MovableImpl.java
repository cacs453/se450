package example.movement;

import example.common.InvalidDataException;
import example.common.LocatableImplFactory;
import example.common.Point3D;
import example.location.Locatable;

/**
 * The implementation class for the Movement, which implements Movable interface.
 */
public class MovableImpl implements Movable {

    private final Point3D destination = new Point3D();//The Point3D value of the destination.
    private double speed; //The current speed.
    private double maxSpeed;//The maxSpeed.
    private Locatable myLocatable;//The instance of Locatable.

    /**
     * The constructor function.
     * @param loc   - The specific current location.
     * @param dest  - The specific destination
     * @param spd   - The specific speed
     * @param mxSpd - The specific max speed
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    public MovableImpl(Point3D loc, Point3D dest, double spd, double mxSpd) throws InvalidDataException {
        setLocatable(LocatableImplFactory.createLocatable(loc));
        setDestination(dest);
        setMaxSpeed(mxSpd);
        setSpeed(spd);
    }

    /**
     * The constructor function.
     * @param lX - x coordinate of the location.
     * @param lY - y coordinate of the location.
     * @param lZ - z coordinate of the location.
     * @param dX - x coordinate of the destination.
     * @param dY - y coordinate of the destination.
     * @param dZ - z coordinate of the destination.
     * @param spd - The current speed.
     * @param mxSpd - The maximum speed.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    public MovableImpl(double lX, double lY, double lZ, double dX, double dY, double dZ,
            double spd, double mxSpd) throws InvalidDataException {
        setLocatable(LocatableImplFactory.createLocatable(new Point3D(lX, lY, lZ)));
        setDestination(dX, dY, dZ);
        setMaxSpeed(mxSpd);
        setSpeed(spd);
    }

    /**
     * Set the specific Locatable instance.
     * @param li - The specific Locatable instance.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    private void setLocatable(Locatable li) throws InvalidDataException {
        if (li == null) {
            throw new InvalidDataException("Null Locatable sent to setLocatable.");
        }
        myLocatable = li;
    }

    /**
     * Get the Locatable instance.
     * @return The Locatable instance.
     */
    private Locatable getLocatable() {
        return myLocatable;
    }

    /**
     * Get the Point3D value of the destination.
     * @return The Point3D value of the destination.
     */
    @Override
    public Point3D getDestination() {
        if (destination == null) {
            return null;
        }
        return new Point3D(destination);
    }

     /**
     * Get x coordinate of the destination.
     * @return x coordinate of the destination.
     */
    @Override
    public double getDestinationX() {
        return destination.getX();
    }

    /**
     * Get y coordinate of the destination.
     * @return y coordinate of the destination.
     */    
    @Override
    public double getDestinationY() {
        return destination.getY();
    }

     /**
     * Get z coordinate of the destination.
     * @return z coordinate of the destination.
     */
    @Override
    public double getDestinationZ() {
        return destination.getZ();
    }

    /**
     * Set the destination with the specific x, y, z coordinates.
     * @param x - x coordinate of the destination.
     * @param y - y coordinate of the destination.
     * @param z - z coordinate of the destination.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    @Override
    public final void setDestination(double x, double y, double z) throws InvalidDataException {
        if (x < 0.0 || y < 0.0 || z < 0.0) {
            throw new InvalidDataException(
                    "Invalid X,Y,Z point sent to setDestination(x,y,z): (" + x + "," + y + "," + z + ")");
        }
        destination.setLocation(x, y, z);
    }

    /**
     * Set the destination with the specific Point3D value.
     * @param aPoint - The specific Point3D value.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    @Override
    public final void setDestination(Point3D aPoint) throws InvalidDataException {
        if (aPoint == null) {
            throw new InvalidDataException("Null Point3D sent to setDestination(Point3D)");
        }
        setDestination(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Get the current speed.
     * @return The current speed.
     */
    @Override
    public double getSpeed() {
        return speed;
    }

    /**
     * Set the current speed.
     * @param s - The specific current speed.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    @Override
    public final void setSpeed(double s) throws InvalidDataException {
        if (s < 0.0) {
            throw new InvalidDataException("Negative speed sent to setSpeed:" + s);
        }
        if (s > getMaxSpeed()) {
            throw new InvalidDataException("Attempt to set speed (" + s + ") greater than maxSpeed (" + getMaxSpeed()
                    + ") in setSpeed");
        }
        speed = s;
    }

    /**
     * Get the maximum speed.
     * @return The maximum speed.
     */
    @Override
    public double getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * Set the maximum speed.
     * @param ms - The specific maximum speed.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    @Override
    public final void setMaxSpeed(double ms) throws InvalidDataException {
        if (ms < 0.0) {
            throw new InvalidDataException("Negative maxSpeed sent to setMaxSpeed:" + ms);
        }
        if (ms < getSpeed()) {
            throw new InvalidDataException("Attempt to set maxSpeed less than speed in setMaxSpeed: " + ms);
        }
        maxSpeed = ms;
    }

    /**
     * Check if the instance is at the destination.
     * @return If the instance is at the destination.
     */
    @Override
    public boolean atDestination() {
        return myLocatable.getLocation().equals(destination);
    }

    /**
     * Calculate the distance from the specific location.
     * @param loc - The specific location.
     * @return The distance from the specific location.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     * @see example.location.LocatableImpl#distance(example.common.Point3D) 
     */
    // From Locatable interface
    @Override
    public double distance(Point3D loc) throws InvalidDataException {
        return myLocatable.distance(loc);
    }

     /**
     * Calculate the distance from the other specific location.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @return The distance from the other specific location
     * @throws InvalidDataException - Invalid inputted parameter exception.
     * @see example.location.LocatableImpl#distance(double, double, double)
     */  
    @Override
    public double distance(double x, double y, double z) throws InvalidDataException {
        return myLocatable.distance(x, y, z);
    }

    /**
     * Get the Point3D value of the location.
     * @return - The Point3D value of the location.
     */    
    @Override
    public Point3D getLocation() {
        return myLocatable.getLocation();
    }

    /**
     * Get the x coordinate of the location.
     * @return - The x coordinate of the location.
     */    
    @Override
    public double getLocationX() {
        return myLocatable.getLocationX();
    }

    /**
     * Get the y coordinate of the location.
     * @return - The y coordinate of the location.
     */      
    @Override
    public double getLocationY() {
        return myLocatable.getLocationY();
    }

    /**
     * Get the z coordinate of the location.
     * @return - The z coordinate of the location.
     */      
    @Override
    public double getLocationZ() {
        return myLocatable.getLocationZ();
    }

    /**
     * Set the location with the specific Point3D value.
     * @param loc - The specific Point3D value.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */    
    @Override
    public void setLocation(Point3D loc) throws InvalidDataException {
        myLocatable.setLocation(loc);
    }

    /**
     * Set the location with 3 coordinates.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */    
    @Override
    public void setLocation(double x, double y, double z) throws InvalidDataException {
        myLocatable.setLocation(x, y, z);
    }

    /**
     * Update the location with the specific time interval.
     * @param millis - The specific time interval
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */
    @Override
    public void update(double millis) throws InvalidDataException {
        // This is a FAKE update method - NOT what you need for your project.
        double time = millis / 1000.0;

        double distanceTraveled = getSpeed() * time;
        double distance = getLocation().distance(getDestination());

        if (distance == 0.0) {
            return;
        }
        if (distanceTraveled >= distance) {
            setLocation(destination);
            return;
        }
        double delta = distanceTraveled / distance;

        double newX = getLocation().getX() + (getDestination().getX() - getLocation().getX()) * delta;
        double newY = getLocation().getY() + (getDestination().getY() - getLocation().getY()) * delta;
        double newZ = getLocation().getZ() + (getDestination().getZ() - getLocation().getZ()) * delta;

        setLocation(newX, newY, newZ);

    }
}
