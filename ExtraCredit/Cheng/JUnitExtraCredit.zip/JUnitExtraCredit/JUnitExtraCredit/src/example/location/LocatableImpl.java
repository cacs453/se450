package example.location;

import example.common.InvalidDataException;
import example.common.Point3D;

/**
 * The implementation class for the Location, which implements Locatable interface.
 */
public class LocatableImpl implements Locatable {

    private final Point3D location = new Point3D(); // The location value.

    /**
     * The constructor function.
     * @param loc - The inputted specific location.
     * @throws InvalidDataException - The invalid inputted parameter exception.
     */
    public LocatableImpl(Point3D loc) throws InvalidDataException {
        setLocation(loc);
    }

     /**
     * The constructor function.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */
    public LocatableImpl(double x, double y, double z) throws InvalidDataException {
        this(new Point3D(x, y, z));
    }

    /**
     * Get the Point3D value of the location.
     * @return - The Point3D value of the location.
     */
    @Override
    public Point3D getLocation() {
        return new Point3D(location);
    }

     /**
     * Get the x coordinate of the location.
     * @return - The x coordinate of the location.
     */
    @Override
    public double getLocationX() {
        return location.getX();
    }

     /**
     * Get the y coordinate of the location.
     * @return - The y coordinate of the location.
     */    
    @Override
    public double getLocationY() {
        return location.getY();
    }

    /**
     * Get the z coordinate of the location.
     * @return - The z coordinate of the location.
     */       
    @Override
    public double getLocationZ() {
        return location.getZ();
    }

    /**
     * Set the location with the specific Point3D value.
     * @param loc - The specific Point3D value.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */
    @Override
    public final void setLocation(Point3D loc) throws InvalidDataException {
        if (loc == null) {
            throw new InvalidDataException("Null location sent to setLocation");
        }

        setLocation(loc.getX(), loc.getY(), loc.getZ());
    }

    /**
     * Set the location with 3 coordinates.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */
    @Override
    public void setLocation(double x, double y, double z) throws InvalidDataException {
        if (x < 0.0 || y < 0.0 || z < 0.0) {
            throw new InvalidDataException("Invalid X,Y,Z point sent to setLocation(x,y,z)");
        }
        location.setCoordinates(x, y, z);
    }

    /**
     * Calculate the distance from the other specific location.
     * @param loc - The other specific location.
     * @return The distance from the other specific location
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */
    @Override
    public double distance(Point3D loc) throws InvalidDataException {
        if (loc == null) {
            throw new InvalidDataException("Null location sent to distance");
        }
        return location.distance(loc);
    }

    /**
     * Calculate the distance from the other specific location.
     * @param x - The specific x coordinate.
     * @param y - The specific y coordinate.
     * @param z - The specific z coordinate.
     * @return The distance from the other specific location
     * @throws InvalidDataException - Invalid inputted parameter exception.
     */    
    @Override
    public double distance(double x, double y, double z) throws InvalidDataException {
        if (x < 0.0 || y < 0.0 || z < 0.0) {
            throw new InvalidDataException("Invalid X,Y,Z point sent to distance(x,y,z)");
        }
        return location.distance(x, y, z);
    }
}
