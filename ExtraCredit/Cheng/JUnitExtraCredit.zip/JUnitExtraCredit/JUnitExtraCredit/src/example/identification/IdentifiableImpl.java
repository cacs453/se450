package example.identification;

import example.common.InvalidDataException;

/**
 * The implementation class for the Identifier, which implements Identifiable interface.
 */
public class IdentifiableImpl implements Identifiable {

    private String identifier; // The Identifier string value.

    /**
     * The constructor function.
     * @param id - The inputted identifier.
     * @throws InvalidDataException 
     */
    public IdentifiableImpl(String id) throws InvalidDataException {
        setIdentifier(id);
    }

    /**
     * Get the identifier.
     * @return The identifier string.
     */
    @Override
    public String getIdentifier() {
        return identifier;
    }

    /**
     * Set the identifier.
     * @param id - The identifier string to be set.
     * @throws InvalidDataException 
     */
    public final void setIdentifier(String id) throws InvalidDataException {
        if (id == null || id.length() == 0) {
            throw new InvalidDataException("Null or empty ID passed to setIdentifier");
        }
        identifier = id;
    }
}
