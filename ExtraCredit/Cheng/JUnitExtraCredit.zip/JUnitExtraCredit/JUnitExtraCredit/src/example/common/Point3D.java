package example.common;

import java.awt.Point;

/**
 * Class that represents the point with 3 dimensions which extends Point.Double.
 */
public class Point3D extends Point.Double {

    /**
     * z - z coordinate
     */
    public double z;
    
    /**
     * Constructor function.
     * @param xIn - Inputted x coordinate.
     * @param yIn - Inputted y coordinate.
     * @param zIn - Inputted z coordinate.
     */
    public Point3D(double xIn, double yIn, double zIn) {
        setCoordinates(xIn, yIn, zIn);
    }

     /**
     * Constructor function.
     * @param xIn - Inputted x coordinate.
     * @param yIn - Inputted y coordinate.
     */
    public Point3D(double xIn, double yIn) {
        setCoordinates(xIn, yIn, 0.0);
    }

     /**
     * Constructor function.
     * @param aPoint - The inputted Point3D instance.
     */    
    public Point3D(Point3D aPoint) {
        setCoordinates(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

     /**
     * Constructor function.
     */      
    public Point3D() {
    }

    /**
     * Get z coordinate.
     * @return The z coordinate.
     */
    public double getZ() {
        return z;
    }

    /**
     * Set the coordinates of the point.
     * @param xIn - Inputted x coordinate.
     * @param yIn - Inputted y coordinate.
     * @param zIn - Inputted z coordinate.
     */
    public final void setCoordinates(double xIn, double yIn, double zIn) {
        x = xIn;
        y = yIn;
        z = zIn;

    }

    /**
     * Set the location of the point by Point3D value.
     * @param aPoint - The Point3D value of the specific location.
     */
    public void setLocation(Point3D aPoint) {
        setCoordinates(aPoint);
    }

    /**
     * Set the location of the point by 3 coordinates.
     * @param xIn - Inputted x coordinate.
     * @param yIn - Inputted y coordinate.
     * @param zIn - Inputted z coordinate.
     */
    public void setLocation(double xIn, double yIn, double zIn) {
        setCoordinates(xIn, yIn, zIn);
    }

     /**
     * Set coordinates of the point by a Point3D value.
     * @param aPoint - The specific Point3D value.
     */
    public void setCoordinates(Point3D aPoint) {
        setCoordinates(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Output the String value of the instance information.
     * @return The String value of the instance information.
     */
    @Override
    public String toString() {
        return String.format("[%-1.2f, %-1.2f, %-1.2f]", x, y, z);
    }

    /**
     * Calculate the distance from the specific point.
     * @param xIn - Inputted x coordinate.
     * @param yIn - Inputted y coordinate.
     * @param zIn - Inputted z coordinate.
     * @return The distance from the specific point.
     */
    public double distance(double xIn, double yIn, double zIn) {
        xIn -= getX();
        yIn -= getY();
        zIn -= getZ();

        return Math.sqrt(xIn * xIn + yIn * yIn + zIn * zIn);
    }

     /**
     * Calculate the distance from the specific point.
     * @param aPoint - The Point3D value of the specific point.
     * @return The distance from the specific point.
     */
    public double distance(Point3D aPoint) {
        return distance(aPoint.getX(), aPoint.getY(), aPoint.getZ());
    }

    /**
     * Check if the current point equals the specific point.
     * @param aPoint3D - The Point3D value of the specific point.
     * @return - If the current point equals the specific point.
     */
    public boolean equals(Point3D aPoint3D) {
        return (getX() == aPoint3D.getX())
                && (getY() == aPoint3D.getY())
                && (getZ() == aPoint3D.getZ());
    }
}
