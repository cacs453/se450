/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.common;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class Point3DTest {
    Point3D testPoint3D;
    Point3D testPoint3D_2;
    final double delta = 0.01;
    
    public Point3DTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        testPoint3D = new Point3D(11.1, 22.2, 33.3);
        testPoint3D_2 = new Point3D(44.4, 55.5, 66.6);
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSetLocation_Point3D() {        
        testPoint3D.setLocation(testPoint3D_2);
        assertTrue(testPoint3D.equals(testPoint3D_2));
    }

    @Test
    public void testSetLocation_3args() {
        testPoint3D.setLocation(44.4, 55.5, 66.6);
        assertTrue(testPoint3D.equals(testPoint3D_2));
    }

    @Test
    public void testSetCoordinates_Point3D() {
        testPoint3D.setCoordinates(testPoint3D_2);
        assertTrue(testPoint3D.equals(testPoint3D_2));
    }

  @Test
    public void testToString() {
        testPoint3D.setLocation(44.4, 55.5, 66.6);
        assertEquals(testPoint3D.toString(), "[44.40, 55.50, 66.60]");
    }
    
    @Test
    public void testDistance_3args() {
        double x = 44.4;
        double y = 55.5;
        double z = 66.6;        
        double distance = testPoint3D.distance(x, y, z);
        double distance2 = Math.sqrt( (x-11.1) * (x-11.1) + (y-22.2) * (y-22.2) + (z-33.3) * (z-33.3));
        assertEquals(distance, distance2, delta);
    }
    
    /**
     * Test of distance method, of class Point3D.
     */
    @Test
    public void testDistance_Point3D() {
        double x = 44.4;
        double y = 55.5;
        double z = 66.6;        
        double distance = testPoint3D.distance(new Point3D(x,y,z));
        double distance2 = Math.sqrt( (x-11.1) * (x-11.1) + (y-22.2) * (y-22.2) + (z-33.3) * (z-33.3));
        assertEquals(distance, distance2, delta);
    }

    /**
     * Test of equals method, of class Point3D.
     */
    @Test
    public void testEquals() {
        assertTrue(testPoint3D.equals(new Point3D(11.1, 22.2, 33.3)));
        assertFalse(testPoint3D.equals(new Point3D(77.7, 22.2, 33.3)));        
    }    
    
    @Test
    public void testPoint3D() {
        assertNotNull(new Point3D());
    }    
    
    @Test
    public void testPoint3D_Point3D() {
        Point3D instance =  new Point3D(testPoint3D);        
        assertNotNull(instance);
        assertTrue(instance.equals(testPoint3D));
    }    
    
    @Test
    public void testPoint3D_2args() {
        Point3D instance =  new Point3D(11.1, 22.2);        
        Point3D instance2 =  new Point3D(11.1, 22.2, 0);                
        assertNotNull(instance);
        assertTrue(instance.equals(instance2));
    }            
}
