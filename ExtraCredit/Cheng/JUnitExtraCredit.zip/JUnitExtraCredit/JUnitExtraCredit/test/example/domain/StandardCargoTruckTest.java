/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.domain;

import example.common.CannotFitException;
import example.common.InvalidDataException;
import example.common.Point3D;
import example.location.LocatableImpl;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class StandardCargoTruckTest {
    private StandardCargoTruck testStandardCargoTruck = null;
    private final double delta =0.01;
    
    public StandardCargoTruckTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        try {
            testStandardCargoTruck = new StandardCargoTruck(1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 8.8, 20.0, 999.0);
        }
        catch(InvalidDataException ex) {
            fail("Creation fails in setUp function of StandardCargoTruckTest.");
        }        
    }
    
    @After
    public void tearDown() {
    }
        
    @Test
    public void testLoad() throws Exception {
        double weight;
        
        weight = -1;
        try{
            testStandardCargoTruck.load(weight);
            fail(String.format("InvalidDataException NOT thrown from StandardCargoTruckTest testLoad with an invalid parameter."));
        }catch(InvalidDataException ex) {
            assertEquals("Negative load amount: " + weight, ex.getMessage());
        }
          
        weight = testStandardCargoTruck.getMaxLoadWeight() + 10;
        try{
            testStandardCargoTruck.load(weight);
            fail(String.format("InvalidDataException NOT thrown from StandardCargoTruckTest testLoad with an invalid parameter."));
        }catch(CannotFitException ex) {
            assertEquals("Additional load of " + weight + " will make the load weight "
                    + (0 + weight) + " which exceeds the max load weight of " + testStandardCargoTruck.getMaxLoadWeight(), ex.getMessage());
        }
     
        weight = 55.5;
        try{
            testStandardCargoTruck.load(weight);
            assertEquals(weight, testStandardCargoTruck.getCurrentLoadWeight(), 0);
          }catch(CannotFitException ex) {
               fail(String.format("InvalidDataException thrown from StandardCargoTruckTest testLoad with a valid parameter."));  
        }                 
    }

    @Test
    public void testUnLoad() throws Exception {
        double weight;
        
        weight = -1;
        try{
            testStandardCargoTruck.unLoad(weight);
            fail(String.format("InvalidDataException NOT thrown from StandardCargoTruckTest testLoad with an invalid parameter."));
        }catch(InvalidDataException ex) {
            assertEquals("Negative unLoad amount: " + weight, ex.getMessage());
        }
          
        weight =  10;
        try{
            testStandardCargoTruck.unLoad(weight);
            fail(String.format("InvalidDataException NOT thrown from StandardCargoTruckTest testLoad with an invalid parameter."));
        }catch(CannotFitException ex) {
            assertEquals("UnLoading " + weight + " will make the load weight negative: "
                    + (0 + weight), ex.getMessage());
        }
     
        weight = 12.2;
        try{
            testStandardCargoTruck.load(55.5);
            testStandardCargoTruck.unLoad(weight);            
            assertEquals(55.5-weight, testStandardCargoTruck.getCurrentLoadWeight(), 0);
          }catch(CannotFitException ex) {
               fail(String.format("InvalidDataException thrown from StandardCargoTruckTest testLoad with a valid parameter."));  
        }  
    }

    @Test
    public void testAtDestination() {
        assertFalse(testStandardCargoTruck.atDestination());
    }

    @Test
    public void testGetDestination() {
        assertTrue(testStandardCargoTruck.getDestination().equals(new Point3D(4.4, 5.5, 6.6) ));
    }

    @Test
    public void testGetDestinationX() {
        assertEquals(testStandardCargoTruck.getDestinationX(), 4.4, 0);
    }

    @Test
    public void testGetDestinationY() {
        assertEquals(testStandardCargoTruck.getDestinationY(), 5.5, 0);
    }

    @Test
    public void testGetDestinationZ() {
         assertEquals(testStandardCargoTruck.getDestinationZ(), 6.6, 0);
    }

    @Test
    public void testGetMaxSpeed() {
        assertEquals(testStandardCargoTruck.getMaxSpeed(), 20.0, 0);
    }

    @Test
    public void testGetSpeed() {
        assertEquals(testStandardCargoTruck.getSpeed(), 8.8, 0);
    }

    @Test
    public void testSetDestination_3args() throws Exception {
        testStandardCargoTruck.setDestination(12.2, 13.3, 14.4);
        assertTrue(testStandardCargoTruck.getDestination().equals(new Point3D(12.2, 13.3, 14.4) ));
    }

    @Test
    public void testSetDestination_Point3D() throws Exception {
        testStandardCargoTruck.setDestination(new Point3D(12.2, 13.3, 14.4));
        assertTrue(testStandardCargoTruck.getDestination().equals(new Point3D(12.2, 13.3, 14.4) ));
    }

    @Test
    public void testSetMaxSpeed() throws Exception {
        testStandardCargoTruck.setMaxSpeed(77.7);
        assertEquals(testStandardCargoTruck.getMaxSpeed(), 77.7, 0);          
    }

    @Test
    public void testSetSpeed() throws Exception {
        testStandardCargoTruck.setSpeed(12.2);
        assertEquals(testStandardCargoTruck.getSpeed(), 12.2, 0);  
    }

   @Test
    public void testDistance_Point3D() throws Exception {
        try{
            Point3D point = new Point3D(9.9, 10.0, 11.1);
            LocatableImpl locatable = new LocatableImpl(testStandardCargoTruck.getLocation());
            assertEquals(testStandardCargoTruck.distance(point), locatable.distance(point), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testDistance_Point3D with a valid parameter."));
        }
    }

    @Test
    public void testDistance_3args() throws Exception {
          try{
            LocatableImpl locatable = new LocatableImpl(testStandardCargoTruck.getLocation());
            assertEquals(testStandardCargoTruck.distance(9.9, 10.0, 11.1), locatable.distance(9.9, 10.0, 11.1), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testDistance_3args with a valid parameter."));
        }
    }
    
    @Test
    public void testGetLocation() {
        assertTrue(testStandardCargoTruck.getLocation().equals(new Point3D(1.1, 2.2, 3.3) ));
    }

    @Test
    public void testGetLocationX() {
        assertEquals(testStandardCargoTruck.getLocationX(), 1.1, 0);
    }

    @Test
    public void testGetLocationY() {
        assertEquals(testStandardCargoTruck.getLocationY(), 2.2, 0);
    }

    @Test
    public void testGetLocationZ() {
        assertEquals(testStandardCargoTruck.getLocationZ(), 3.3, 0);
    }

     @Test
     public void testSetLocation_Point3D() {
         Point3D newPoint = new Point3D(99.9, 88.8, 77.7);
         try {
         testStandardCargoTruck.setLocation(newPoint);
         Point3D p = testStandardCargoTruck.getLocation();
         assertNotNull(p);
         assertEquals(p, newPoint);
         assertNotSame(p, newPoint);
         } catch (InvalidDataException ex) {
             fail("InvalidDataException (" + ex.getMessage() + ") thrown from LocatableImpl"
                     + "setLocation(Point3D) with a valid Point3D: " + newPoint);
         }
         
         newPoint = new Point3D(-55.5, 66.6, 77.7);
         try {
             testStandardCargoTruck.setLocation(newPoint);
             fail("InvalidDataException  NOT thrown from LocatableImpl"
                     + "setLocation(Point3D) with an invalid Point3D: " + newPoint);
         }
         catch (InvalidDataException ex) {
             assertEquals(ex.getMessage(), "Invalid X,Y,Z point sent to setLocation(x,y,z)");
             assertFalse(newPoint.equals(testStandardCargoTruck.getLocation()));
         }
         
         newPoint = null;
         try {
             testStandardCargoTruck.setLocation(newPoint);
             fail("InvalidDataException  NOT thrown from LocatableImpl"
                     + "setLocation(Point3D) with null Point3D");
         }
         catch (InvalidDataException ex) {
             assertEquals(ex.getMessage(), "Null location sent to setLocation");
             assertNotNull(testStandardCargoTruck.getLocation());
         }
     }
     
     @Test
     public void testSetLocation_3args() {
         double x = 99.9;
         double y = 88.8;
         double z = 77.7;
         try {
             testStandardCargoTruck.setLocation(x, y, z);
              assertEquals(x, testStandardCargoTruck.getLocationX(), delta); assertEquals(y, testStandardCargoTruck.getLocationY(), delta); assertEquals(z, testStandardCargoTruck.getLocationZ(), delta);
         }
         catch (InvalidDataException ex) {
             fail("InvalidDataException (" + ex.getMessage() + ") thrown from LocatableImpl" +  "setLocation(Point3D) with a valid x, y, z: " + x + ", " + y + ", " + z);
         }
         
         x=-11.1;
         y=22.2;
         z=33.3;
         try{
             testStandardCargoTruck.setLocation(x, y, z);
             fail("InvalidDataException NOT thrown from LocatableImpl setLocation(Point3D) " +" with a invalid x, y, z: " + x + ", " + y + ", " + z);
             } 
         catch (InvalidDataException ex) {
                assertEquals(ex.getMessage(), "Invalid X,Y,Z point sent to setLocation(x,y,z)"); assertTrue(x != testStandardCargoTruck.getLocationX());
                assertTrue(y != testStandardCargoTruck.getLocationY());
                assertTrue(z != testStandardCargoTruck.getLocationZ());
             }
     }

    @Test
    public void testGetMaxLoadWeight() {
        assertEquals(testStandardCargoTruck.getMaxLoadWeight(), 999.0, 0);
    }

    @Test
    public void testSetCurrentLoadWeight() {
        testStandardCargoTruck.setCurrentLoadWeight(22.2);
        assertEquals(testStandardCargoTruck.getCurrentLoadWeight(), 22.2, 0);        
    }

    @Test
    public void testGetCurrentLoadWeight() {
        assertEquals(testStandardCargoTruck.getCurrentLoadWeight(), 0, 0);
    }

    @Test
    public void testGetIdentifier() {
        String identifier = testStandardCargoTruck.getIdentifier();
        assertNotNull(identifier);
        //System.out.println(identifier);
    }

@Test
    public void testUpdate() throws Exception {
        double span = 0;
        Point3D oldLocation = testStandardCargoTruck.getLocation();
        
        // Test the time span of 0 millisecond.
        try{            
            testStandardCargoTruck.update(span);            
            assertTrue(testStandardCargoTruck.getLocation().equals(oldLocation));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
        
        // Test the time span that can arrive at the destination.
        span = 1000 * testStandardCargoTruck.distance(testStandardCargoTruck.getDestination()) / testStandardCargoTruck.getSpeed();                
        try{            
            testStandardCargoTruck.update(span);            
            assertTrue(testStandardCargoTruck.getLocation().equals(testStandardCargoTruck.getDestination()));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
        
        // Test the time span that will exceed the destination.
        span = 5000 + 1000 * testStandardCargoTruck.distance(testStandardCargoTruck.getDestination()) / testStandardCargoTruck.getSpeed(); 
        testStandardCargoTruck.setLocation(oldLocation);
        try{            
            testStandardCargoTruck.update(span);            
            assertTrue(testStandardCargoTruck.getLocation().equals(testStandardCargoTruck.getDestination()));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
    }
    
    @Test
    public void testConstructor_Point3D() {
        try {
            testStandardCargoTruck = new StandardCargoTruck(new Point3D(1.1, 2.2, 3.3), new Point3D(4.4, 5.5, 6.6), 8.8, 20.0, 999.0);
        }
        catch(InvalidDataException ex) {
            fail("InvalidDataException thrown from testStandardCargoTruck testConstructor_Point3D with a valid parameter.");
        }    
    }

    @Test
    public void testToString() {
        try{
        String str = "I am StandardCargoTruck " + testStandardCargoTruck.getIdentifier() + ".\n\tI am at "
                    + testStandardCargoTruck.getLocation() + " and am heading to " + testStandardCargoTruck.getDestination()
                    + ".\n\tMy load is " + testStandardCargoTruck.getCurrentLoadWeight() + " and my max load is "
                    + testStandardCargoTruck.getMaxLoadWeight() + ".\n\tDistance to my destination is "
                    + String.format("%4.2f", testStandardCargoTruck.distance(testStandardCargoTruck.getDestination())) + ". "
                    + (testStandardCargoTruck.atDestination() ? "I am there!" : "I'm not there yet");
        String toString = testStandardCargoTruck.toString();
        assertEquals(toString, str);      
        } catch (InvalidDataException ex) {
            fail("InvalidDataException thrown from testToString testStandardCargoTruck with a valid parameter.");
        }
    }

}
