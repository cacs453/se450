/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.domain;

import example.common.CannotFitException;
import example.common.InvalidDataException;
import example.common.Point3D;
import example.location.LocatableImpl;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
 public class ContainerTruckTest {
    private ContainerTruck testContainerTruck = null;
    private final double delta =0.01;
    
    public ContainerTruckTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        try {
            testContainerTruck = new ContainerTruck(1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 8.8, 20.0, 999.0);
        }
        catch(InvalidDataException ex) {
            fail("Creation fails in setUp function of ContainerTruckTest.");
        }        
    }
    
    @After
    public void tearDown() {
    }
        
    @Test
    public void testLoad() throws Exception {
        double weight = 1.1;
        try{
            testContainerTruck.load(weight);
            fail(String.format("InvalidDataException NOT thrown from ContainerTruckTest testLoad with an invalid parameter."));  
        }catch(InvalidDataException ex) {
            assertEquals(ex.getMessage(), "A Container Truck can only be *fully* loaded (" + testContainerTruck.getMaxLoadWeight()
                    + ")- not partially loaded (" + weight + ")");
        }
     
        weight = testContainerTruck.getMaxLoadWeight();        
        try{
            testContainerTruck.load(weight);
            assertEquals(testContainerTruck.getCurrentLoadWeight(), weight, delta);
        }catch(InvalidDataException ex) {
             fail(String.format("InvalidDataException thrown from ContainerTruckTest testLoad with a valid parameter."));          
        }
    }

    @Test
    public void testUnLoad() throws Exception {
        double weight = 1.1;
        try{
            testContainerTruck.unLoad(weight);
            fail(String.format("InvalidDataException NOT thrown from ContainerTruckTest testUnLoad with an invalid parameter."));  
        }catch(InvalidDataException ex) {
            assertEquals(ex.getMessage(), "A Container Truck can only be *fully* unloaded (" + testContainerTruck.getMaxLoadWeight()
                    + ")- not partially unloaded (" + weight + ")");
        }
                 
        weight = testContainerTruck.getMaxLoadWeight();        
        try{
            testContainerTruck.load(weight);
            testContainerTruck.unLoad(weight);
            assertEquals(testContainerTruck.getCurrentLoadWeight(),0, delta);
        }catch(InvalidDataException ex) {
             fail(String.format("InvalidDataException thrown from ContainerTruckTest testUnLoad with a valid parameter."));          
        }
    }

    @Test
    public void testAtDestination() {
        assertFalse(testContainerTruck.atDestination());
    }

    @Test
    public void testGetDestination() {
        assertTrue(testContainerTruck.getDestination().equals(new Point3D(4.4, 5.5, 6.6) ));
    }

    @Test
    public void testGetDestinationX() {
        assertEquals(testContainerTruck.getDestinationX(), 4.4, 0);
    }

    @Test
    public void testGetDestinationY() {
        assertEquals(testContainerTruck.getDestinationY(), 5.5, 0);
    }

    @Test
    public void testGetDestinationZ() {
         assertEquals(testContainerTruck.getDestinationZ(), 6.6, 0);
    }

    @Test
    public void testGetMaxSpeed() {
        assertEquals(testContainerTruck.getMaxSpeed(), 20.0, 0);
    }

    @Test
    public void testGetSpeed() {
        assertEquals(testContainerTruck.getSpeed(), 8.8, 0);
    }

    @Test
    public void testSetDestination_3args() throws Exception {
        testContainerTruck.setDestination(12.2, 13.3, 14.4);
        assertTrue(testContainerTruck.getDestination().equals(new Point3D(12.2, 13.3, 14.4) ));
    }

    @Test
    public void testSetDestination_Point3D() throws Exception {
        testContainerTruck.setDestination(new Point3D(12.2, 13.3, 14.4));
        assertTrue(testContainerTruck.getDestination().equals(new Point3D(12.2, 13.3, 14.4) ));
    }

    @Test
    public void testSetMaxSpeed() throws Exception {
        testContainerTruck.setMaxSpeed(77.7);
        assertEquals(testContainerTruck.getMaxSpeed(), 77.7, 0);          
    }

    @Test
    public void testSetSpeed() throws Exception {
        testContainerTruck.setSpeed(12.2);
        assertEquals(testContainerTruck.getSpeed(), 12.2, 0);  
    }

   @Test
    public void testDistance_Point3D() throws Exception {
        try{
            Point3D point = new Point3D(9.9, 10.0, 11.1);
            LocatableImpl locatable = new LocatableImpl(testContainerTruck.getLocation());
            assertEquals(testContainerTruck.distance(point), locatable.distance(point), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testDistance_Point3D with a valid parameter."));
        }
    }

    @Test
    public void testDistance_3args() throws Exception {
          try{
            LocatableImpl locatable = new LocatableImpl(testContainerTruck.getLocation());
            assertEquals(testContainerTruck.distance(9.9, 10.0, 11.1), locatable.distance(9.9, 10.0, 11.1), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testDistance_3args with a valid parameter."));
        }
    }
    
    @Test
    public void testGetLocation() {
        assertTrue(testContainerTruck.getLocation().equals(new Point3D(1.1, 2.2, 3.3) ));
    }

    @Test
    public void testGetLocationX() {
        assertEquals(testContainerTruck.getLocationX(), 1.1, 0);
    }

    @Test
    public void testGetLocationY() {
        assertEquals(testContainerTruck.getLocationY(), 2.2, 0);
    }

    @Test
    public void testGetLocationZ() {
        assertEquals(testContainerTruck.getLocationZ(), 3.3, 0);
    }

     @Test
     public void testSetLocation_Point3D() {
         Point3D newPoint = new Point3D(99.9, 88.8, 77.7);
         try {
         testContainerTruck.setLocation(newPoint);
         Point3D p = testContainerTruck.getLocation();
         assertNotNull(p);
         assertEquals(p, newPoint);
         assertNotSame(p, newPoint);
         } catch (InvalidDataException ex) {
             fail("InvalidDataException (" + ex.getMessage() + ") thrown from LocatableImpl"
                     + "setLocation(Point3D) with a valid Point3D: " + newPoint);
         }
         
         newPoint = new Point3D(-55.5, 66.6, 77.7);
         try {
             testContainerTruck.setLocation(newPoint);
             fail("InvalidDataException  NOT thrown from LocatableImpl"
                     + "setLocation(Point3D) with an invalid Point3D: " + newPoint);
         }
         catch (InvalidDataException ex) {
             assertEquals(ex.getMessage(), "Invalid X,Y,Z point sent to setLocation(x,y,z)");
             assertFalse(newPoint.equals(testContainerTruck.getLocation()));
         }
         
         newPoint = null;
         try {
             testContainerTruck.setLocation(newPoint);
             fail("InvalidDataException  NOT thrown from LocatableImpl"
                     + "setLocation(Point3D) with null Point3D");
         }
         catch (InvalidDataException ex) {
             assertEquals(ex.getMessage(), "Null location sent to setLocation");
             assertNotNull(testContainerTruck.getLocation());
         }
     }
     
     @Test
     public void testSetLocation_3args() {
         double x = 99.9;
         double y = 88.8;
         double z = 77.7;
         try {
             testContainerTruck.setLocation(x, y, z);
              assertEquals(x, testContainerTruck.getLocationX(), delta); assertEquals(y, testContainerTruck.getLocationY(), delta); assertEquals(z, testContainerTruck.getLocationZ(), delta);
         }
         catch (InvalidDataException ex) {
             fail("InvalidDataException (" + ex.getMessage() + ") thrown from LocatableImpl" +  "setLocation(Point3D) with a valid x, y, z: " + x + ", " + y + ", " + z);
         }
         
         x=-11.1;
         y=22.2;
         z=33.3;
         try{
             testContainerTruck.setLocation(x, y, z);
             fail("InvalidDataException NOT thrown from LocatableImpl setLocation(Point3D) " +" with a invalid x, y, z: " + x + ", " + y + ", " + z);
             } 
         catch (InvalidDataException ex) {
                assertEquals(ex.getMessage(), "Invalid X,Y,Z point sent to setLocation(x,y,z)"); assertTrue(x != testContainerTruck.getLocationX());
                assertTrue(y != testContainerTruck.getLocationY());
                assertTrue(z != testContainerTruck.getLocationZ());
             }
     }

    @Test
    public void testGetMaxLoadWeight() {
        assertEquals(testContainerTruck.getMaxLoadWeight(), 999.0, 0);
    }

    @Test
    public void testSetCurrentLoadWeight() {
        testContainerTruck.setCurrentLoadWeight(22.2);
        assertEquals(testContainerTruck.getCurrentLoadWeight(), 22.2, 0);        
    }

    @Test
    public void testGetCurrentLoadWeight() {
        assertEquals(testContainerTruck.getCurrentLoadWeight(), 0, 0);
    }

    @Test
    public void testGetIdentifier() {
        String identifier = testContainerTruck.getIdentifier();
        assertNotNull(identifier);
        //System.out.println(identifier);
    }

@Test
    public void testUpdate() throws Exception {
        double span = 0;
        Point3D oldLocation = testContainerTruck.getLocation();
        
        // Test the time span of 0 millisecond.
        try{            
            testContainerTruck.update(span);            
            assertTrue(testContainerTruck.getLocation().equals(oldLocation));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
        
        // Test the time span that can arrive at the destination.
        span = 1000 * testContainerTruck.distance(testContainerTruck.getDestination()) / testContainerTruck.getSpeed();                
        try{            
            testContainerTruck.update(span);            
            assertTrue(testContainerTruck.getLocation().equals(testContainerTruck.getDestination()));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
        
        // Test the time span that will exceed the destination.
        span = 5000 + 1000 * testContainerTruck.distance(testContainerTruck.getDestination()) / testContainerTruck.getSpeed(); 
        testContainerTruck.setLocation(oldLocation);
        try{            
            testContainerTruck.update(span);            
            assertTrue(testContainerTruck.getLocation().equals(testContainerTruck.getDestination()));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
    }
    
    @Test
    public void testConstructor_Point3D() {
        try {
            testContainerTruck = new ContainerTruck(new Point3D(1.1, 2.2, 3.3), new Point3D(4.4, 5.5, 6.6), 8.8, 20.0, 999.0);
        }
        catch(InvalidDataException ex) {
            fail("InvalidDataException thrown from testContainerTruck testConstructor_Point3D with a valid parameter.");
        }    
    }
    
    @Test
    public void testToString()  {           
        try{
        String str = "I am ContainerTruck " + testContainerTruck.getIdentifier() + ".\n\tI am at "
                    + testContainerTruck.getLocation() + " and am heading to " + testContainerTruck.getDestination()
                    + ".\n\tMy load is " + testContainerTruck.getCurrentLoadWeight() + " and my max load is "
                    + testContainerTruck.getMaxLoadWeight() + ".\n\tDistance to my destination is "
                    + String.format("%4.2f", testContainerTruck.distance(testContainerTruck.getDestination())) + ". "
                    + (testContainerTruck.atDestination() ? "I am there!" : "I'm not there yet");
        assertEquals(testContainerTruck.toString(), str);         
        } catch (InvalidDataException ex) {
            fail("InvalidDataException thrown from testToString testContainerTruck with a valid parameter.");
        }
    }
}

