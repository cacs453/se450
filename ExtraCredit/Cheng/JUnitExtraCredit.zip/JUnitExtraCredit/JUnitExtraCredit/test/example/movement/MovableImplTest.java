/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.movement;

import example.common.InvalidDataException;
import example.common.Point3D;
import example.location.Locatable;
import example.location.LocatableImpl;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class MovableImplTest {    
    private MovableImpl testMovableImpl;
    private double delta = 0.01;
    
    public MovableImplTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        try {
            testMovableImpl = new MovableImpl(1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 8.8, 20.0);
        }
        catch(InvalidDataException ex) {
            fail("Creation fails in setUp of MovableImplTest.");
        }
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testGetDestination() {
        Point3D point = new Point3D(4.4, 5.5, 6.6);
        assertTrue(testMovableImpl.getDestination().equals(point));
        
//        MovableImpl instance=null;                                             
//        try{        
//            instance = new MovableImpl(new Point3D(1.1, 2.2, 3.3), null, 8.8, 20.0);  
//            assertNull(instance.getDestination());
//        }catch(InvalidDataException ex) {
//            fail(String.format("InvalidDataException thrown from MovableImplTest testGetDestination with a valid parameter"));
//        }  
    }

    @Test
    public void testGetDestinationX() {
        assertEquals(testMovableImpl.getDestinationX(), 4.4, delta);
    }

    @Test
    public void testGetDestinationY() {
        assertEquals(testMovableImpl.getDestinationY(), 5.5, delta);
    }

    @Test
    public void testGetDestinationZ() {
        assertEquals(testMovableImpl.getDestinationZ(), 6.6, delta);
    }

//    @Test 
//    public void testSetLocatable() {
//         try{
//            testMovableImpl.setLocatable(null);
//           fail(String.format("InvalidDataException NOT thrown from MovableImplTest testSetLocatable with a null parameter."));
//        }catch(InvalidDataException ex) {
//           assertEquals(ex.getMessage(), "Null Locatable sent to setLocatable.");
//        }
//    }
    
    @Test
    public void testSetDestination_Point3D() throws Exception {
          try{
            testMovableImpl.setDestination(null);
            fail(String.format("InvalidDataException NOT thrown from MovableImplTest testSetDestination_3args with an null parameter."));  
        }catch(InvalidDataException ex) {            
            assertEquals(ex.getMessage(), "Null Point3D sent to setDestination(Point3D)");                                  
        }
    }
            
    @Test
    public void testSetDestination_3args() throws Exception {
        try{
            testMovableImpl.setDestination(11.3, 12.4, 13.5);
            assertTrue(testMovableImpl.getDestination().equals(new Point3D(11.3, 12.4, 13.5) ));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testSetDestination_3args with a valid parameter."));            
        }
        
        try{
            testMovableImpl.setDestination(-11.3, 12.4, 13.5);
            //fail(String.format("InvalidDataException NOT thrown from MovableImplTest testSetDestination_3args with an invalid parameter."));            
        }catch(InvalidDataException ex) {
            //assertEquals(ex.getMessage(), "Invalid X,Y,Z point sent to setDestination(x,y,z): (" + -11.3 + "," + 12.4 + "," + 13.5 + ")");
        }                       
    }

    @Test
    public void testGetSpeed() {
        assertEquals(testMovableImpl.getSpeed(), 8.8, delta);
    }

    @Test
    public void testSetSpeed() throws Exception {
        double s = -1.0;
        try{
            testMovableImpl.setSpeed(s);
            fail(String.format("InvalidDataException NOT thrown with invalid parameter %f in testSetSpeed of MovableImplTest", s));
        }catch(InvalidDataException ex) {
            assertEquals("Negative speed sent to setSpeed:" + s , ex.getMessage());
        }
        
        s = testMovableImpl.getMaxSpeed() + 1.0;
        try{
            testMovableImpl.setSpeed(s);
            fail(String.format("InvalidDataException NOT thrown with invalid parameter %f in testSetSpeed of MovableImplTest", s));
        }catch(InvalidDataException ex) {
            assertEquals("Attempt to set speed (" + s + ") greater than maxSpeed (" + testMovableImpl.getMaxSpeed()
                    + ") in setSpeed" , ex.getMessage());
        }
        
        s = 9.9;
        try{
            testMovableImpl.setSpeed(s);
            assertEquals(s, testMovableImpl.getSpeed(), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown with a valid parameter %f in testSetSpeed of MovableImplTest", s));
        }
    }

    @Test
    public void testGetMaxSpeed() {
        assertEquals(testMovableImpl.getMaxSpeed(), 20.0, delta);
    }

    @Test
    public void testSetMaxSpeed() throws Exception {
        double s = -1.0;
        try{
            testMovableImpl.setMaxSpeed(s);
            fail(String.format("InvalidDataException NOT thrown with invalid parameter %f in testSetMaxSpeed of MovableImplTest", s));
        }catch(InvalidDataException ex) {
            assertEquals("Negative maxSpeed sent to setMaxSpeed:" + s , ex.getMessage());
        }
        
        s = testMovableImpl.getSpeed() - 1.0;
        try{
            testMovableImpl.setMaxSpeed(s);
            fail(String.format("InvalidDataException NOT thrown with invalid parameter %f in testSetMaxSpeed of MovableImplTest", s));
        }catch(InvalidDataException ex) {
            assertEquals("Attempt to set maxSpeed less than speed in setMaxSpeed: " + s , ex.getMessage());
        }
        
        s = 29.9;
        try{
            testMovableImpl.setMaxSpeed(s);
            assertEquals(s, testMovableImpl.getMaxSpeed(), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown with a valid parameter %f in testSetMaxSpeed of MovableImplTest", s));
        }
    }

    @Test
    public void testAtDestination() {
        assertFalse(testMovableImpl.atDestination());
        try{
            testMovableImpl.setLocation(testMovableImpl.getDestination());
            assertTrue(testMovableImpl.atDestination());
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException THROWN with a valid parameter when setLocation in testAtDestination of MovableImplTest."));
        }
    }

    @Test
    public void testDistance_Point3D() throws Exception {
        try{
            Point3D point = new Point3D(9.9, 10.0, 11.1);
            LocatableImpl locatable = new LocatableImpl(testMovableImpl.getLocation());
            assertEquals(testMovableImpl.distance(point), locatable.distance(point), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testDistance_Point3D with a valid parameter."));
        }
    }

    @Test
    public void testDistance_3args() throws Exception {
          try{
            LocatableImpl locatable = new LocatableImpl(testMovableImpl.getLocation());
            assertEquals(testMovableImpl.distance(9.9, 10.0, 11.1), locatable.distance(9.9, 10.0, 11.1), delta);
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testDistance_3args with a valid parameter."));
        }
    }

    @Test
    public void testGetLocation() {
        assertEquals(testMovableImpl.getSpeed(), 8.8, delta);
    }

    @Test
    public void testGetLocationX() {
        assertEquals(testMovableImpl.getLocationX(), 1.1, delta);
    }

    @Test
    public void testGetLocationY() {
        assertEquals(testMovableImpl.getLocationY(), 2.2, delta);
    }

    @Test
    public void testGetLocationZ() {
        assertEquals(testMovableImpl.getLocationZ(), 3.3, delta);
    }

    @Test
    public void testSetLocation_3args() throws Exception {
        try{
            testMovableImpl.setLocation(4.4, 5.5, 6.6);            
            assertTrue(testMovableImpl.getLocation().equals(new Point3D(4.4, 5.5, 6.6)));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testSetLocation_3args with a valid parameter"));
        }
    }

    @Test
    public void testUpdate() throws Exception {
        double span = 0;
        Point3D oldLocation = testMovableImpl.getLocation();
        
        // Test the time span of 0 millisecond.
        try{            
            testMovableImpl.update(span);            
            assertTrue(testMovableImpl.getLocation().equals(oldLocation));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
        
        // Test the time span that can arrive at the destination.
        span = 1000 * testMovableImpl.distance(testMovableImpl.getDestination()) / testMovableImpl.getSpeed();                
        try{            
            testMovableImpl.update(span);            
            assertTrue(testMovableImpl.getLocation().equals(testMovableImpl.getDestination()));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
        
        // Test the time span that will exceed the destination.
        span = 5000 + 1000 * testMovableImpl.distance(testMovableImpl.getDestination()) / testMovableImpl.getSpeed(); 
        testMovableImpl.setLocation(oldLocation);
        try{            
            testMovableImpl.update(span);            
            assertTrue(testMovableImpl.getLocation().equals(testMovableImpl.getDestination()));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }
    }

//    @Test
//    public void testGetLocatable() {
//        assertNotNull(testMovableImpl.getLocatable());
//    }

     @Test
    public void testConstructor() {                                             
        try{        
            MovableImpl instance = new MovableImpl(new Point3D(1.1, 2.2, 3.3), new Point3D(4.4, 5.5, 6.6), 8.8, 20.0);  
            assertNotNull(instance);
            assertTrue(instance.getLocation().equals(testMovableImpl.getLocation()));   
            assertTrue(instance.getDestination().equals(testMovableImpl.getDestination()));          
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testUpdate with a valid parameter"));
        }                    
    }       

    @Test
    public void testSetLocation_Point3D() throws Exception {
       try{
            testMovableImpl.setLocation(new Point3D(4.4, 5.5, 6.6));            
            assertTrue(testMovableImpl.getLocation().equals(new Point3D(4.4, 5.5, 6.6)));
        }catch(InvalidDataException ex) {
            fail(String.format("InvalidDataException thrown from MovableImplTest testSetLocation_3args with a valid parameter"));
        }
    }

}
