/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example.identification;

import example.common.InvalidDataException;
import example.identification.IdentifiableImpl;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jason
 */
public class IdentifiableImplTest {
    IdentifiableImpl testIdentifiableImpl;
    
    public IdentifiableImplTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        try{
            testIdentifiableImpl = new IdentifiableImpl("id");
        }
        catch(InvalidDataException ex) {
            fail(String.format("Fail to create testIdentifiableImpl in setUp: %s", ex.getMessage()));
        }
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testGetIdentifier() {
        assertEquals(testIdentifiableImpl.getIdentifier(),  "id");
    }

    @Test
    public void testSetIdentifier() throws Exception {
        String id = null;
        try {
            testIdentifiableImpl.setIdentifier(id);
            fail("InvalidDataException NOT thrown with null parameter in testSetIdentifier of IdentifiableImplTest.");
        }
        catch(InvalidDataException ex) {
            assertEquals("Null or empty ID passed to setIdentifier", ex.getMessage());
        }
        
        id = "";
        try {
            testIdentifiableImpl.setIdentifier(id);
            fail("InvalidDataException NOT thrown with empty parameter in testSetIdentifier of IdentifiableImplTest.");
        }
        catch(InvalidDataException ex) {
            assertEquals("Null or empty ID passed to setIdentifier", ex.getMessage());
        }
        
        id = "test";
        try {
            testIdentifiableImpl.setIdentifier(id);
            assertEquals(id, testIdentifiableImpl.getIdentifier());    
        }
        catch(InvalidDataException ex) {
            fail("InvalidDataException thrown with valid parameter in testSetIdentifier of IdentifiableImplTest.");
        }
    }
    
}
