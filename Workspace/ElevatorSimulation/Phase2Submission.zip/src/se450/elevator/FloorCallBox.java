package se450.elevator;

import se450.elevator.common.DIRECTION;


/**
 * Hasn't implemented for Phase II
 * 
 * @author Cheng Zhang
 *
 */
public class FloorCallBox {
	private Floor parentFloor; 
	private DIRECTION status;
	private void pressButton(Person person, DIRECTION input) {
		
	}
	
	public FloorCallBox(Floor floor) {
		
	}
	
	public void pressUp(Person person) {
		
	}
	
	public void pressDown(Person person) {
		
	}
	
	// reset up status
	public void resetUp() {
		
	}
	
	// reset down status	
	public void resetDown() {
		
	}
	
}
