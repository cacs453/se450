package se450.elevator;
/**
 * Hasn't been implemented during Phase II. 
 */
public class FloorImpl implements Floor {

}
