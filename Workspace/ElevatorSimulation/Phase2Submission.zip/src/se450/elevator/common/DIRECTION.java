package se450.elevator.common;
/**
 * Enum for moving direction
 * 
 * @author Shan Gao
 *
 */
public enum DIRECTION  {
	NONE, 
	UP, 
	DOWN 
};
