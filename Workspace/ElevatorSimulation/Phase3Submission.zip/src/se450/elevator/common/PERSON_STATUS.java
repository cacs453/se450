package se450.elevator.common;
/**
 * Enum for person status
 * 
 * @author Shan Gao
 *
 */
public enum PERSON_STATUS 
{	NONE, 
	WAITING, 
	RIDDING, 
	ARRIVED
};
