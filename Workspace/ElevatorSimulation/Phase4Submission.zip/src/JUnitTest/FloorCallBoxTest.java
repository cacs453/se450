package JUnitTest;

import static org.junit.Assert.*;
import junit.framework.TestCase;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * JUNIT test.
 * 
 * @author Cheng Zhang
 *
 */
public class FloorCallBoxTest extends TestCase {

	@BeforeClass
	public static void setUpBeforeClass() throws RuntimeException  {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFloorCallBox() {
		
	}

}
